//! Builder patterns and DI
