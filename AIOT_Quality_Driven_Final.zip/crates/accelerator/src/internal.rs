//! Internal implementation details
