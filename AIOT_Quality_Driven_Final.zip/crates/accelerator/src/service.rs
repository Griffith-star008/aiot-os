//! Core logic services
