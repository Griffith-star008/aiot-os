//! Error enums
