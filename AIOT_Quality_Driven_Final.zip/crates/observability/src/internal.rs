//! Internal logic
